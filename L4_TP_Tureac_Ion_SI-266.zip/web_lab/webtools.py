# Laborator: functii, metode si importuri pe web
# Student: Tureac Ion
# Modul propriu cu functii reutilizabile pentru rapoarte web.

import time
import json
import csv
import socket
import ssl
import hashlib
import re
import requests
import urllib.parse
from datetime import datetime

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

DEFAULT_HEADERS = {"User-Agent": "WebLab-Tureac Ion"}


# --- functii de baza ---

def fetch(url, timeout=TIMEOUT):
    """Descarca url si returneaza obiectul response."""
    return requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)


def get_status(url):
    """Returneaza codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code


def get_title(html):
    """Primeste un string HTML si returneaza titlul paginii."""
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    if start < len("<title>") or end == -1:
        return ""
    return html[start:end].strip()


# --- securitate ---

def security_headers(url):
    """Verifica prezenta antetelor de securitate. Returneaza {antet: bool}."""
    headers_to_check = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
    ]
    r = fetch(url)
    return {h: h in r.headers for h in headers_to_check}


def score_headers(results):
    """Returneaza scorul sub forma 'X/5' din dictionarul de antete."""
    total = len(results)
    present = sum(1 for v in results.values() if v)
    return f"{present}/{total}"


# --- DNS si certificat ---

def resolve(hostname):
    """Returneaza adresa IP a hostname-ului."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname):
    """Returneaza cate zile mai sunt pana expira certificatul TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
    expire_ts = ssl.cert_time_to_seconds(cert["notAfter"])
    return int((expire_ts - time.time()) / 86400)


# --- linkuri ---

def extract_links(html):
    """Returneaza lista de linkuri href din HTML, fara duplicate."""
    found = re.findall(r'href="([^"]+)"', html)
    seen = []
    for link in found:
        if link not in seen:
            seen.append(link)
    return seen


def split_links(links, base, domain):
    """Returneaza (interne, externe) pentru lista de linkuri."""
    internal, external = [], []
    for link in links:
        full = urllib.parse.urljoin(base, link)
        netloc = urllib.parse.urlparse(full).netloc
        if netloc == domain:
            internal.append(full)
        else:
            external.append(full)
    return internal, external


# --- robots.txt ---

def fetch_robots(base):
    """Returneaza textul din /robots.txt sau None daca lipseste."""
    try:
        r = fetch(base + "/robots.txt")
        if r.status_code == 200:
            return r.text
        return None
    except requests.RequestException:
        return None


def disallowed_paths(robots_text):
    """Returneaza lista de cai din liniile 'Disallow:' din robots.txt."""
    if robots_text is None:
        return []
    paths = []
    for line in robots_text.splitlines():
        if line.strip().lower().startswith("disallow:"):
            value = line.split(":", 1)[1].strip()
            if value:
                paths.append(value)
    return paths


# --- verificare cai ---

def check_paths(base, paths):
    """Returneaza {path: status_code} pentru fiecare cale din lista."""
    result = {}
    for path in paths:
        result[path] = get_status(base + path)
        time.sleep(1)
    return result


def save_csv(filename, data):
    """Salveaza {path: status} in CSV cu coloanele path, status, checked_at."""
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["path", "status", "checked_at"])
        now = datetime.now().isoformat()
        for path, status in data.items():
            writer.writerow([path, status, now])


# --- raport final ---

def site_report(url):
    """Colecteaza toate informatiile despre site si le salveaza in report.json."""
    r = fetch(url)
    domain = urllib.parse.urlparse(url).netloc

    # redirectari de la http://
    history = []
    if url.startswith("https://"):
        http_url = "http://" + url[len("https://"):]
        try:
            r_http = fetch(http_url)
            for resp in r_http.history:
                history.append(f"{resp.status_code} -> {resp.url}")
            if r_http.url != http_url and not history:
                history.append(f"{r_http.status_code} -> {r_http.url}")
        except requests.RequestException:
            pass

    title = get_title(r.text)
    ip = resolve(domain)
    score = score_headers(security_headers(url))
    days = cert_days_left(domain)

    links = extract_links(r.text)
    internal, external = split_links(links, url, domain)

    robots = fetch_robots(url)
    forbidden = disallowed_paths(robots)

    report = {
        "url": url,
        "status": r.status_code,
        "final_url": r.url,
        "title": title,
        "ip": ip,
        "redirects": history,
        "security_score": score,
        "cert_days_left": days,
        "internal_links": len(internal),
        "external_links": len(external),
        "disallowed_paths": forbidden,
    }

    # afisare
    print(f"=== Raport site: {url} ===")
    print(f"Cod de stare: {r.status_code}")
    print(f"URL final: {r.url}")
    print(f"Titlu: {title}")
    print(f"Adresa IP: {ip}")
    print(f"Redirectari: {history if history else 'niciuna'}")
    print(f"Scor securitate: {score}")
    print(f"Certificat: {days} zile ramase")
    print(f"Legaturi: {len(internal)} interne, {len(external)} externe")
    print(f"Cai interzise: {', '.join(forbidden) if forbidden else 'niciuna'}")

    with open("report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print("Salvat in report.json")
    return report


# --- autotest (ruleaza doar cand executi direct webtools.py) ---
if __name__ == "__main__":
    print("Autotest:", get_status(BASE_URL))