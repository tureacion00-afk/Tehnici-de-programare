# Laborator: functii, metode si importuri pe web
# Student: Tureac Ion

import time
import requests
import requests as rq
import urllib.request
from requests import get

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

# --- Ex 1 ---
print("requests version:", requests.__version__)
# requests a avut nevoie de pip install pentru ca e pachet extern.
# urllib.request vine cu Python, nu trebuie instalat separat.

# --- Ex 2 ---
r = requests.get(BASE_URL, timeout=TIMEOUT)
print("stil 1:", r.status_code)
time.sleep(1)

r = get(BASE_URL, timeout=TIMEOUT)
print("stil 2:", r.status_code)
# import requests: se vede de unde vine functia, am acces la tot modulul.
# from ... import get: scriu mai scurt, dar risc sa suprascriu get cu o
# functie proprie.

# --- Ex 3 ---
r = rq.get(BASE_URL, timeout=TIMEOUT)
print("statusul este:", r.status_code)
time.sleep(1)
# alias bun: nume lung folosit des (numpy as np). Scriu mai putin.
# alias rau: prea scurt/neobisnuit (requests as x). Cod criptic.

# --- Ex 4 ---
req = urllib.request.Request(BASE_URL, headers={"User-Agent": "Mozilla/5.0"})
with urllib.request.urlopen(req, timeout=TIMEOUT) as response:
    print("status urllib:", response.status)
    body = response.read().decode("utf-8")
    print(body[:200])
time.sleep(1)

# --- Ex 5 ---
print(dir(requests))
# get -> functie, Session -> clasa, exceptions -> modul

# --- Ex 6 ---
help(requests.get)
r = requests.get(BASE_URL, timeout=5)
print("status cu timeout=5:", r.status_code)
time.sleep(1)
# parametrul din help() pentru timp maxim de asteptare este "timeout".

# --- Ex 7 ---
start = time.perf_counter()
r = requests.get(BASE_URL, timeout=TIMEOUT)
end = time.perf_counter()
print("timp real:", round(end - start, 3), "s")
print("elapsed:", r.elapsed.total_seconds(), "s")
time.sleep(1)
# perf_counter masoara tot (DNS + TCP + TLS + cerere + raspuns).
# elapsed masoara doar timpul serverului pana la primul byte.

# --- Ex 8 ---
try:
    import bs4
    print("bs4 este instalat")
except ImportError:
    print("Instalati modulul cu: pip install beautifulsoup4")