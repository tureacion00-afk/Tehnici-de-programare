# Laborator: functii, metode si importuri pe web
# Student: Tureac Ion
# Program principal: importa webtools si genereaza raportul.

import argparse
import webtools
from webtools import get_title, security_headers, DEFAULT_HEADERS

# Ex 44: apel prin modul
# print(webtools.get_title(webtools.fetch(webtools.BASE_URL).text))

# Ex 45: daca as avea si eu o functie get_title aici, a mea ar
# suprascrie-o pe cea importata (shadowing). As pierde accesul la
# functia din modul fara sa-mi dau seama.

# Ex 47: constanta importata
print("DEFAULT_HEADERS:", DEFAULT_HEADERS)


# Ex 48: argumente din linia de comanda
parser = argparse.ArgumentParser(description="Raport despre un site web.")
parser.add_argument("url", help="URL-ul site-ului de analizat")
args = parser.parse_args()

# Ex 49: salvare CSV cu check_paths
paths = ["/", "/robots.txt", "/sitemap.xml"]
result = webtools.check_paths(args.url, paths)
webtools.save_csv("report.csv", result)
print("Salvat report.csv")

# Ex 50: raportul complet
webtools.site_report(args.url)