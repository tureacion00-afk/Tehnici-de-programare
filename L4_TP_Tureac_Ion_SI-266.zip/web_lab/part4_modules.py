# Laborator: functii, metode si importuri pe web
# Student: Tureac Ion

import time
import json
import socket
import ssl
import hashlib
import re
import requests
import urllib.parse
from html.parser import HTMLParser
from datetime import datetime

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


# --- Ex 35: descompunerea unui URL ---
def parse_url(url: str) -> dict:
    """Descompune un URL in componentele sale."""
    p = urllib.parse.urlparse(url)
    return {
        "scheme": p.scheme,
        "netloc": p.netloc,
        "path": p.path,
        "query": p.query,
        "fragment": p.fragment,
    }


parsed = parse_url("https://cybercor.org/path?x=1#top")
for key, value in parsed.items():
    print(f"Ex 35 {key}: {value}")


# --- Ex 36: compunerea URL-urilor ---
def join_links(base: str, relatives: list) -> list:
    """Transforma linkuri relative in URL-uri complete."""
    return [urllib.parse.urljoin(base, r) for r in relatives]


joined = join_links(BASE_URL, ["/about", "contact.html", "../index.html"])
print("Ex 36:")
for url in joined:
    print(" ", url)


# --- Ex 37: extragerea legaturilor ---
def extract_links(html: str) -> list:
    """Returneaza lista de linkuri href din HTML, fara duplicate."""
    found = re.findall(r'href="([^"]+)"', html)
    # eliminam duplicatele pastrand ordinea
    seen = []
    for link in found:
        if link not in seen:
            seen.append(link)
    return seen


r = requests.get(BASE_URL, timeout=TIMEOUT)
links = extract_links(r.text)
print("Ex 37 numar linkuri unice:", len(links))
time.sleep(1)


# --- Ex 38: interne sau externe ---
def split_links(links: list, domain: str) -> tuple:
    """Returneaza (interne, externe) pentru lista de linkuri."""
    internal, external = [], []
    for link in links:
        full = urllib.parse.urljoin(BASE_URL, link)
        netloc = urllib.parse.urlparse(full).netloc
        if netloc == domain:
            internal.append(full)
        else:
            external.append(full)
    return internal, external


internal, external = split_links(links, "cybercor.org")
print("Ex 38 interne:", len(internal), "externe:", len(external))


# --- Ex 39: propriile metode - ImageFinder ---
class ImageFinder(HTMLParser):
    """Parser care colecteaza src-ul fiecarui tag <img>."""

    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "img":
            src = dict(attrs).get("src")
            if src:
                self.images.append(src)


# test pe HTML cunoscut
test_html = """
<html><body>
<img src="/logo.png" alt="Logo">
<IMG SRC="poza.jpg">
<img alt="imagine fara src">
<img src="https://cdn.example.com/banner.webp" />
<a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""

finder = ImageFinder()
finder.feed(test_html)
print("Ex 39 test:", finder.images)
assert finder.images == [
    "/logo.png",
    "poza.jpg",
    "https://cdn.example.com/banner.webp",
], "Parserul nu a gasit exact imaginile asteptate"
print("Testul a trecut!")

# rulare pe pagina reala
r = requests.get(BASE_URL, timeout=TIMEOUT)
finder = ImageFinder()
finder.feed(r.text)
print("Ex 39 imagini gasite pe site:", len(finder.images))
time.sleep(1)


# --- Ex 40: amprenta paginii ---
def page_fingerprint(url: str) -> str:
    """Returneaza hash-ul sha256 al continutului paginii."""
    r = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(r.content).hexdigest()


h1 = page_fingerprint(BASE_URL)
time.sleep(1)
h2 = page_fingerprint(BASE_URL)
print("Ex 40 hash 1:", h1)
print("Ex 40 hash 2:", h2)
print("Ex 40 identice:", h1 == h2)
# ar fi diferite daca pagina s-ar schimba intre cele doua cereri (continut
# dinamic, timestamp, sesiune diferita).


# --- Ex 41: salvarea in JSON ---
r = requests.get(BASE_URL, timeout=TIMEOUT)
with open("headers.json", "w", encoding="utf-8") as f:
    json.dump(dict(r.headers), f, indent=2)

with open("headers.json", "r", encoding="utf-8") as f:
    loaded = json.load(f)

print("Ex 41 Server din fisier:", loaded.get("Server", "lipseste"))
time.sleep(1)


# --- Ex 42: interogare DNS ---
def resolve(hostname: str) -> str:
    """Returneaza adresa IP a hostname-ului."""
    return socket.gethostbyname(hostname)


print("Ex 42 IP cybercor.org:", resolve("cybercor.org"))


# --- Ex 43: expirarea certificatului ---
def cert_days_left(hostname: str) -> int:
    """Returneaza cate zile mai sunt pana expira certificatul TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()

    expire_str = cert["notAfter"]
    expire_ts = ssl.cert_time_to_seconds(expire_str)
    now_ts = time.time()
    days = int((expire_ts - now_ts) / 86400)
    return days


print("Ex 43 zile pana expira:", cert_days_left("cybercor.org"), "zile")