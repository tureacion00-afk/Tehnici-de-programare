# Laborator: functii, metode si importuri pe web
# Student: Tureac Ion

import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


# --- Ex 21: prima functie ---
def fetch(url):
    """Returneaza obiectul response pentru adresa url."""
    return requests.get(url, timeout=TIMEOUT)


r = fetch(BASE_URL)
print("Ex 21 status:", r.status_code)
time.sleep(1)


# --- Ex 22: returnarea unei singure valori ---
def get_status(url):
    """Returneaza codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code


for path in ["/", "/robots.txt", "/sitemap.xml"]:
    print(path, "->", get_status(BASE_URL + path))
    time.sleep(1)


# --- Ex 23: parametri impliciti ---
def fetch2(url, timeout=10):
    """Descarca url si returneaza response. Timeout implicit 10 secunde."""
    return requests.get(url, timeout=timeout)


r = fetch2(BASE_URL)                 # foloseste timeout=10
print("Ex 23 default:", r.status_code)
time.sleep(1)

r = fetch2(BASE_URL, timeout=3)      # foloseste timeout=3
print("Ex 23 timeout=3:", r.status_code)
time.sleep(1)


# --- Ex 24: o singura sarcina pe functie ---
def get_title(html):
    """Primeste un string HTML si returneaza titlul paginii."""
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    return html[start:end].strip()


r = requests.get(BASE_URL, timeout=TIMEOUT)
print("Ex 24 titlu:", get_title(r.text))
time.sleep(1)


# --- Ex 25: docstring-uri ---
help(get_title)


# --- Ex 26: adnotari de tip ---
def get_status2(url: str) -> int:
    """Returneaza codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code


print("Ex 26 status:", get_status2(BASE_URL))
time.sleep(1)

# get_status2(123)  # <- ar da eroare la requests, nu la Python.
# Adnotarile de tip NU opresc executia. Sunt doar indicii pentru
# programator si pentru tool-uri (mypy, IDE). Python le ignora la runtime.


# --- Ex 27: fara opriri neasteptate ---
def page_exists(url: str) -> bool:
    """Returneaza True daca pagina exista, False altfel."""
    try:
        r = requests.get(url, timeout=TIMEOUT)
        return r.status_code < 400
    except requests.RequestException:
        return False


print("Ex 27 cybercor:", page_exists(BASE_URL))
print("Ex 27 invalid:", page_exists("https://this-domain-does-not-exist.invalid"))
time.sleep(1)


# --- Ex 28: returnarea unui dictionar ---
def check_paths(base: str, paths: list) -> dict:
    """Returneaza {path: status_code} pentru fiecare cale din lista."""
    result = {}
    for path in paths:
        r = requests.get(base + path, timeout=TIMEOUT)
        result[path] = r.status_code
        time.sleep(1)
    return result


print("Ex 28:", check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"]))


# --- Ex 29: argumente cu nume ---
def get_header(url: str, name: str, default: str = "lipseste") -> str:
    """Returneaza valoarea unui singur antet, sau default daca lipseste."""
    r = requests.get(url, timeout=TIMEOUT)
    return r.headers.get(name, default)


print("Ex 29 Server:", get_header(BASE_URL, name="Server"))
time.sleep(1)


# --- Ex 30: antete de securitate ---
def security_headers(url: str) -> dict:
    """Verifica prezenta antetelor de securitate. Returneaza {antet: bool}."""
    headers_to_check = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
    ]
    r = requests.get(url, timeout=TIMEOUT)
    return {h: h in r.headers for h in headers_to_check}


print("Ex 30:", security_headers(BASE_URL))
time.sleep(1)


# --- Ex 31: functii care apeleaza functii ---
def score_headers(results: dict) -> str:
    """Returneaza scorul sub forma 'X/5' din dictionarul de antete."""
    total = len(results)
    present = sum(1 for v in results.values() if v)
    return f"{present}/{total}"


print("Ex 31 scor:", score_headers(security_headers(BASE_URL)))
time.sleep(1)


# --- Ex 32: doua functii, o sarcina ---
def fetch_robots(base: str):
    """Returneaza textul din /robots.txt sau None daca lipseste."""
    try:
        r = requests.get(base + "/robots.txt", timeout=TIMEOUT)
        if r.status_code == 200:
            return r.text
        return None
    except requests.RequestException:
        return None


def disallowed_paths(robots_text):
    """Returneaza lista de cai din liniile 'Disallow:' din robots.txt."""
    if robots_text is None:
        return []
    paths = []
    for line in robots_text.splitlines():
        if line.strip().lower().startswith("disallow:"):
            value = line.split(":", 1)[1].strip()
            if value:
                paths.append(value)
    return paths


robots = fetch_robots(BASE_URL)
print("Ex 32 cai interzise:", disallowed_paths(robots))
print("Ex 32 None test:", disallowed_paths(None))
time.sleep(1)


# --- Ex 33: oricate argumente ---
def response_times(*urls: str) -> dict:
    """Returneaza {url: secunde} pentru fiecare url primit."""
    times = {}
    for url in urls:
        start = time.perf_counter()
        requests.get(url, timeout=TIMEOUT)
        end = time.perf_counter()
        times[url] = round(end - start, 3)
        time.sleep(1)
    return times


print("Ex 33:", response_times(BASE_URL, BASE_URL + "/robots.txt"))


# --- Ex 34: argumente cu nume colectate ---
def log(message: str, **details):
    """Afiseaza mesajul urmat de fiecare detaliu cheie=valoare."""
    parts = [message]
    for key, value in details.items():
        parts.append(f"{key}={value}")
    print(" | ".join(parts))


log("verificat", url=BASE_URL, status=200)