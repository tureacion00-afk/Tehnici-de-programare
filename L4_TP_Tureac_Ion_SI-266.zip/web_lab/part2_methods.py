# Laborator: functii, metode si importuri pe web
# Student: Tureac Ion

import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


# --- Ex 9: elementele de baza ale raspunsului ---
r = requests.get(BASE_URL, timeout=TIMEOUT)
print(r.status_code)    # atribut
print(r.ok)             # atribut
print(r.url)            # atribut
print(r.encoding)       # atribut
time.sleep(1)


# --- Ex 10: tratarea erorilor cu o metoda ---
r = requests.get(BASE_URL, timeout=TIMEOUT)
r.raise_for_status()
print("pagina principala: ok")
time.sleep(1)

try:
    r = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    r.raise_for_status()
except requests.HTTPError:
    print("Pagina nu exista sau serverul a refuzat cererea.")
time.sleep(1)


# --- Ex 11: toate antetele ---
r = requests.get(BASE_URL, timeout=TIMEOUT)
for name, value in r.headers.items():
    print(f"{name}: {value}")
time.sleep(1)


# --- Ex 12: metode de dictionar ---
server = r.headers.get("Server", "lipseste")
content_type = r.headers.get("Content-Type", "lipseste")
print("Server:", server)
print("Content-Type:", content_type)

lower = r.headers.get("content-type", "lipseste")
print("content-type (lowercase):", lower)
time.sleep(1)
# headers e un CaseInsensitiveDict: "Content-Type" si "content-type"
# returneaza aceeasi valoare. HTTP nu face diferenta intre majuscule
# si minuscule in numele antetelor.


# --- Ex 13: inlantuirea metodelor de string ---
r = requests.get(BASE_URL, timeout=TIMEOUT)
count = r.text.lower().count("cyber")
print("cyber apare de", count, "ori")
time.sleep(1)
# putem inlantui .lower() si .count() pentru ca ambele sunt metode de
# string si fiecare returneaza un string (lower) sau un numar (count).
# lower() transforma textul, count() numara pe rezultat.


# --- Ex 14: gasirea titlului ---
html = r.text
start = html.find("<title>") + len("<title>")
end = html.find("</title>")
title = html[start:end].strip()
print("Titlu:", title)
time.sleep(1)


# --- Ex 15: numararea liniilor ---
lines = html.splitlines()
print("Numar linii:", len(lines))
print("Cea mai lunga linie:", len(max(lines, key=len)))
time.sleep(1)


# --- Ex 16: verificarea HTTPS ---
r = requests.get(BASE_URL, timeout=TIMEOUT)
if r.url.startswith("https://"):
    print("Conexiune securizata")
else:
    print("Conexiune nesecurizata")
time.sleep(1)


# --- Ex 17: urmarirea redirectarilor ---
r = requests.get("http://cybercor.org", timeout=TIMEOUT)
for resp in r.history:
    print(resp.status_code, "->", resp.url)
print("Final:", r.url)
time.sleep(1)


# --- Ex 18: HEAD versus GET ---
r_head = requests.head(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
r_get = requests.get(BASE_URL, timeout=TIMEOUT)
print("HEAD content length:", len(r_head.content))
print("GET content length:", len(r_get.content))
time.sleep(1)
# HEAD cere doar antetele, nu si corpul paginii. De aceea content e gol
# (0 bytes). GET descarca si corpul, deci content are marimea HTML-ului.


# --- Ex 19: cookie-uri ---
r = requests.get(BASE_URL, timeout=TIMEOUT)
if r.cookies:
    for cookie in r.cookies:
        print(cookie.name, "secure:", cookie.secure)
else:
    print("Niciun cookie setat")
time.sleep(1)


# --- Ex 20: sesiuni ---
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-Tureac Ion"})
r = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
data = r.json()
print("User-Agent trimis:", data["headers"].get("User-Agent"))
time.sleep(1)